import {Routeur} from "./pages/Routeur"
import "./css/main.css";

function App() {
	return (
	<Routeur/>
	);
}

export default App;