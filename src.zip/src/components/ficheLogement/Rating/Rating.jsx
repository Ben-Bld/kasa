


export function Rating() {
    return (
        <div >

        </div>
    )
}