
import logements from "../../../datas/logements.json"


export function Tags(props) {

    let tagsLogement = props.tags
    console.log(tagsLogement)

    return (
        <div className="container-tag" >
            {tagsLogement.map((item) => (
                <div key={item} className="container-tag__item">
                    {/* {tagsLogement} */}
                </div>
            ))
            }
        </div >
    )
}