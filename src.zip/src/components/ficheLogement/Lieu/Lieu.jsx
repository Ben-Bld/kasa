


export function Lieu(props) {
    return (
        <div className="container-lieu" >
            <p>{props.lieu}</p>
        </div>
    )
}